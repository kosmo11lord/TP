package com.example.task6;

public class base {
    static final int size = 50000002;
    static final int half = size / 2;

    public static void main(String[] args) {



        //Метод 1

        long a = System.currentTimeMillis();
        float[] arr = new float[size];
        for (int i = 0; i < size; i++) {
            arr[i] = 1;
            arr[i] = (float) (arr[i] * Math.sin(0.2f + i / 5) * Math.cos(0.2f + i / 5) * Math.cos(0.4f + i / 2));
        }
        System.out.println(arr[0]);
        System.out.println(arr[size - 1]);
        System.out.println("время " + (System.currentTimeMillis() - a));

        //Метод 2

        a = System.currentTimeMillis();
        arr = new float[size];

        float[] a1 = new float[half];
        float[] a2 = new float[half];
        System.arraycopy(arr, 0, a1, 0, half);
        System.arraycopy(arr, half, a2, 0, half);

        Thread t = new Thread(() -> {
            for (int i = 0; i < half; i++) {
                a1[i] = 1;
                a1[i] = (float) (a1[i] * Math.sin(0.2f + i / 5) * Math.cos(0.2f + i / 5) * Math.cos(0.4f + i / 2));
            }
        });

        t.start();
        for (int i = 0; i < half; i++) {
            a2[i] = 1;
            a2[i] = (float) (a2[i] * Math.sin(0.2f + (i + half) / 5) * Math.cos(0.2f + (i + half) / 5) * Math.cos(0.4f + (i + half) / 2));
        }
        System.arraycopy(a1, 0, arr, 0, half);
        System.arraycopy(a2, 0, arr, half, half);

        System.out.println(arr[0]);
        System.out.println(arr[size - 1]);
        System.out.println("время " + (System.currentTimeMillis() - a));

        //Метод 3

        a = System.currentTimeMillis();
        float[] arr1 = new float[size];
        int part = 5;
        int sizePart = size / part;
        Thread[] threads = new Thread[part];

        float[] t1 = new float[sizePart];
        float[] t2 = new float[sizePart];
        float[] t3 = new float[sizePart] ;
        float[] t4 = new float[sizePart];

        float[] arrTemp1 = new float[size-sizePart*(part-1)];
        for (int j = 0; j < arrTemp1.length; j++) {
            arrTemp1[j] = 1;
            arrTemp1[j] = (float) (arrTemp1[j] * Math.sin(0.2f + (j+sizePart*(part-1)) / 5) * Math.cos(0.2f + (j+sizePart*(part-1)) / 5) * Math.cos(0.4f + (j+sizePart*(part-1)) / 2));
        }
//        System.out.print("Поток " + 1);
//        for (float p: arrTemp1){
//            System.out.print(" " + p + " ");
//        }
        System.out.println();
        System.arraycopy(arrTemp1, 0, arr1 , sizePart*(part-1), arrTemp1.length);

        for (int i = 0; i < part - 1; i++) {
            int finalI = i;

            threads[i] = new Thread(() -> {
                float[] arrTemp = new float[sizePart];
                for (int j = 0; j < sizePart; j++) {
                    arrTemp[j] = 1;
                    arrTemp[j] = (float) (arrTemp[j] * Math.sin(0.2f + (j+ sizePart* finalI) / 5) * Math.cos(0.2f + (j+ sizePart* finalI) / 5) * Math.cos(0.4f + (j+ sizePart* finalI) / 2));
//                    switch (finalI) {
//                        case 0 -> {
//                            t1[j] = arrTemp[j];
//                        }
//                        case 1 -> {
//                            t2[j] = arrTemp[j];
//                        }
//                        case 2 -> {
//                            t3[j] = arrTemp[j];
//                        }
//                        case 3 -> {
//                            t4[j] = arrTemp[j];
//                        }
//                    }
                }
                System.arraycopy(arrTemp, 0, arr1 , sizePart * finalI, sizePart);
            });
            threads[i].start();
        }

        try {
            for (int i = 0; i<(part-1);i++) {threads[i].join();}
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
//        System.out.print("Поток " + 2);
//        for (float p: t1){
//            System.out.print(" " + p + " ");
//        }
//        System.out.println();
//        System.out.print("Поток " + 3);
//        for (float p: t2){
//            System.out.print(" " + p + " ");
//        }
//        System.out.println();
//        System.out.print("Поток " + 4);
//        for (float p: t3){
//            System.out.print(" " + p + " ");
//        }
//        System.out.println();
//        System.out.print("Поток " + 5);
//        for (float p: t4){
//            System.out.print(" " + p + " ");
//        }

        System.out.println(arr1[0]);
        System.out.println(arr1[size - 1]);
        System.out.println("время " + (System.currentTimeMillis() - a));
    }
}

