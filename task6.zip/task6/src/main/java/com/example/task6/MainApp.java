package com.example.task6;

public class MainApp {
    static final int size = 50000002;

    public static void main(String[] args) {
        long a = System.currentTimeMillis();
        float[] arr1 = new float[size];
        int part = 5;
        int sizePart = size / part;
        Thread[] threads = new Thread[part];

        float[] arrTemp1 = new float[size-sizePart*(part-1)];
        for (int j = 0; j < arrTemp1.length; j++) {
            arrTemp1[j] = 1;
            arrTemp1[j] = (float) (arrTemp1[j] * Math.sin(0.2f + (j+sizePart*(part-1)) / 5) * Math.cos(0.2f + (j+sizePart*(part-1)) / 5) * Math.cos(0.4f + (j+sizePart*(part-1)) / 2));
        }
        System.arraycopy(arrTemp1, 0, arr1 , sizePart*(part-1), arrTemp1.length);
        System.out.println(arrTemp1.length);

        for (int i = 0; i < part - 1; i++) {
            int finalI = i;

            threads[i] = new Thread(() -> {
                float[] arrTemp = new float[sizePart];
                for (int j = 0; j < sizePart; j++) {
                    arrTemp[j] = 1;
                    arrTemp[j] = (float) (arrTemp[j] * Math.sin(0.2f + (j+ sizePart* finalI) / 5) * Math.cos(0.2f + (j+ sizePart* finalI) / 5) * Math.cos(0.4f + (j+ sizePart* finalI) / 2));
                }
                System.arraycopy(arrTemp, 0, arr1 , sizePart * finalI, sizePart);
                System.out.println(arrTemp.length);
            });
            threads[i].start();
        }

        try {
            for (int i = 0; i<(part-1);i++) {threads[i].join();}
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(arr1[0]);
        System.out.println(arr1[size - 1]);
        System.out.println(System.currentTimeMillis() - a);
    }
}