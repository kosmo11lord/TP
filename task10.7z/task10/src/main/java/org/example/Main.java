package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    static Connection connection;
    static Statement statement;

    public static void main(String[] args) throws SQLException {
        connect();
//        statement.execute("drop table if exists Result;");
//        statement.execute("drop table if exists Student;");
//        statement.execute("drop table if exists Discipline;");
//
//        statement.execute("CREATE TABLE IF NOT EXISTS Student" +
//                "(id serial not null PRIMARY KEY," +
//                " name varchar(30) not null," +
//                " passportSeries varchar(4) not null," +
//                " passportNumber varchar(6) not null," +
//                " UNIQUE (passportSeries, passportNumber));");
//
//        statement.execute("CREATE TABLE IF NOT EXISTS Discipline" +
//                "(id serial not null PRIMARY KEY, disciplines varchar(50) not null);");
//
//        statement.execute("CREATE TABLE IF NOT EXISTS Result" +
//                "(id serial not null PRIMARY KEY," +
//                " student int not null REFERENCES Student(id) ON DELETE CASCADE," +
//                " discipline int not null REFERENCES Discipline(id)," +
//                " mark smallint CHECK(mark BETWEEN 2 and 5));");
//
//        statement.execute("INSERT into Student (name, passportSeries, passportNumber) values" +
//                "    ('Артём', 3294, 658824)," +
//                "    ('Савелий', 3275, 226854)," +
//                "    ('Роман', 3759, 358647)," +
//                "    ('Андрей', 3085, 123659)," +
//                "    ('Алексей', 3196, 758426)," +
//                "    ('Данил', 3345, 159705)," +
//                "    ('Сергей', 3368, 958624);");
//
//        statement.execute("INSERT into Discipline (disciplines) values" +
//                "    ('Математика')," +
//                "    ('Русский язык')," +
//                "    ('Английский язык')," +
//                "    ('Литература')," +
//                "    ('Физкультура')," +
//                "    ('ИЗО')," +
//                "    ('Информатика');");
//
//        statement.execute("INSERT into Result (student, discipline, mark) values" +
//                "    (7, 1, 5)," +
//                "    (6, 2, 4)," +
//                "    (5, 3, 3)," +
//                "    (4, 4, 2)," +
//                "    (3, 5, 5)," +
//                "    (2, 1, 4)," +
//                "    (2, 2, 4)," +
//                "    (2, 3, 4)," +
//                "    (2, 4, 4)," +
//                "    (2, 5, 4)," +
//                "    (2, 6, 4)," +
//                "    (2, 7, 4)," +
//                "    (1, 2, 5)," +
//                "    (1, 3, 4)," +
//                "    (1, 4, 5)," +
//                "    (1, 5, 5)," +
//                "    (1, 6, 4)," +
//                "    (1, 7, 4)," +
//                "    (7, 1, 2)," +
//                "    (6, 2, 5)," +
//                "    (5, 3, 4)," +
//                "    (4, 4, 3)," +
//                "    (3, 5, 2);");

        System.out.println("Вывести список студентов, сдавших определенный предмет, на оценку выше 3: ");
        var res1 = statement.executeQuery("Select s.name, r.mark, d.disciplines from Student s " +
                "join Result r on s.id = r.student " +
                "join Discipline d on d.id = r.discipline " +
                "WHERE r.mark > 3 and d.disciplines = 'Математика';");
        while (res1.next()) {
            String subjName = res1.getString(1);
            int mark = res1.getInt(2);
            String studName = res1.getString(3);
            System.out.println(subjName + " " + mark + " " + studName+"\n");
        }

        System.out.print("Посчитать средний балл по определенному предмету: ");
        var res2 = statement.executeQuery("select avg(r.mark) from Result r " +
                "join Discipline d on r.discipline = d.id " +
                "where d.disciplines = 'Литература';");
        while (res2.next()) {
            double avg = res2.getDouble(1);
            System.out.println(avg+"\n");
        }

        System.out.print("Посчитать средний балл по определенному студенту: ");
        var res3 = statement.executeQuery("select avg(r.mark) from Student s " +
                "join Result r on s.id = r.student " +
                "where s.name = 'Сергей';");
        while (res3.next()) {
            double avg = res3.getDouble(1);
            System.out.println(avg+"\n");
        }

        System.out.println("Найти три предмета, которые сдали наибольшее количество студентов: ");
        var res4 = statement.executeQuery("SELECT count(*), d.disciplines from Result r " +
                "join Discipline d on d.id = r.discipline " +
                "where r.mark > 2 " +
                "group by d.disciplines " +
                "order by count(*) desc limit 3;");
        while (res4.next()) {
            int cnt = res4.getInt(1);
            String name = res4.getString(2);
            System.out.println(cnt + " " + name);
        }
        System.out.println("Найти студентов на стипендии отсортировав");
        var res5 = statement.executeQuery("select s.name, avg(r.mark) from Student s join Result r on s.id = r.student\n" +
                "where name not in (select name from student s join result r on s.id = r.student\n" +
                "                                     where r.mark<4 or r.mark is null)\n" +
                "group by s.id, s.name\n" +
                "having count(r.discipline) = (select count(*) from Discipline)\n" +
                "order by avg(r.mark) desc;");
        while (res5.next()) {
            String name = res5.getString(1);
            double cnt = res5.getDouble(2);
            System.out.println(name + " " + String.format("%.1f",cnt));
        }
        disconnect();
    }

    public static void connect(){
        try{
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tp","Aerlen","");
            statement = connection.createStatement();
        }
        catch (ClassNotFoundException| SQLException e){
            e.printStackTrace();
        }
    }
    public static void disconnect() {
        try {
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}