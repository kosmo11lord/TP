package com.example.task8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class test
{
    //    public class Person{
    //        int age;
    //        String name;
    //         position;
    //
    //        public Person(int age, String name) {
    //            this.age = age;
    //            this.name = name;
    //        }
    //    }

    public static void main(String[] args)
    {
        //    List<Person> engeneerName = new ArrayList<>();
        //    List<String> engeneerName = new ArrayList<>();
        //    engeneers.add(o);
        //
        //    List<String> engineerNameShort = people.stream()
        //            .filter(person -> person.position == Person.Position.ENGINEER)
        //            .sorted((o1,o2)->(o1.age - o2.age))
        //            .map((Function<Person,String>) person->person.name)
        //            .collect(Collectors.toList());

        List<Integer> number = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
        List<Integer> out = number
                .stream()
                .limit(3)
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .collect(Collectors.toList());

        List<Integer> out1 = number
                .stream()
                .limit(3)
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .collect(Collectors.toList());

        Arrays.asList(4, 2, 3, 4, 1, 2, 2, 3, 4).stream().distinct().forEach(n -> System.out.println(n));
    }
}
