package com.example.task8;

import java.util.*;
import java.util.stream.Collectors;

public class MainApp
{
    public static void main(String[] args)
    {
        //1
        String[] words = new String[]{"woo", "sto", "sun", "water", "sun", "sto", "water", "sun", "sto", "woo", "woo"};

        String collect = Arrays
                .stream(words)
                .collect(Collectors.groupingBy(w -> w, Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(Comparator.comparing(e -> e.getKey().length()))
                .filter(e -> e.getKey().length() == Arrays
                        .stream(words)
                        .collect(Collectors.groupingBy(w -> w, Collectors.counting()))
                        .entrySet()
                        .stream()
                        .max(Comparator.comparingLong(s -> s.getValue()))
                        .get()
                        .getKey()
                        .length())
                .map(e -> e.getKey())
                .collect(Collectors.joining(", "));

        System.out.println(collect);

//        String collect2 = Arrays
//                .stream(words)
//                .collect(Collectors.groupingBy(w -> w, Collectors.counting()))
//                .entrySet()
//                .stream()
//                .collect(Collectors.groupingBy(Map.Entry::getValue, Collectors.mapping(Map.Entry::getKey, Collectors.toCollection(HashSet::new))))
//                .entrySet()
//                .stream()
//                .max(Map.Entry.comparingByKey())
//                .map(longHashSetEntry -> longHashSetEntry
//                        .getValue()
//                        .stream()
//                        .filter(s -> s.length() == longHashSetEntry
//                                .getValue()
//                                .stream()
//                                .min((o1, o2) -> o2.length() - o1.length())
//                                .get()
//                                .length()))
//                .get()
//                .collect(Collectors.joining(", "));
//
//        System.out.println(collect2);

        //2
        int n = 3;
        List<Student> students = new ArrayList<>(Arrays.asList(
                new Student("Артём", "МиXXXеев", 1, 4.2),
                new Student("Оптимус", "Прайм", 10, 10.0),
                new Student("Оптимус", "Прайм1", 11, 10.0),
                new Student("Андрей", "Белянин", 3, 4.4),
                new Student("Савелий", "Вотинцев", 4, 5),
                new Student("Данил", "Шалагин", 2, 4.4)
        ));

        String sortStudent = students
                .stream()
                .sorted(Comparator.comparingDouble(Student::getAvgMark).reversed().thenComparingInt(Student::getCourse))
                .limit(n)
                .sorted(Comparator.comparingInt(Student::getCourse))
                .map(student -> student.getLastName())
                .collect(Collectors.joining(", ", n + " самых успешных студентов зовут: ", "."));

        System.out.println(sortStudent);
    }

}

class Student
{
    private final String name;
    private final String lastName;
    private final Integer course;
    private final double avgMark;

    public Student(String name, String lastName, Integer course, double avgMark)
    {
        this.name = name;
        this.lastName = lastName;
        this.course = course;
        this.avgMark = avgMark;
    }

    public String getLastName()
    {
        return lastName;
    }

    public Integer getCourse()
    {
        return course;
    }

    public double getAvgMark()
    {
        return avgMark;
    }
}
