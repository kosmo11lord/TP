package task3;
class MyArraySizeException extends RuntimeException {
    MyArraySizeException() {
        super("Размерность массива должна быть 4x4");
    }
}

class MyArrayDataException extends RuntimeException {
    MyArrayDataException(int row, int col) {
        super("Неверные данные находятся в ячейке [" + (row + 1) + "," + (col + 1) + "]");
    }
}

class MyPowException extends RuntimeException {
    MyPowException(int row, int col) {
        super("Не полный квадрат или куб находятся в ячейке [" + (row + 1) + "," + (col + 1) + "]");
    }
}

class MyLichrelException extends RuntimeException {
    MyLichrelException(int row, int col) {
        super("Число Лихрела в ячейке [" + (row + 1) + "," + (col + 1) + "]");
    }
}
public class MainApp {
    public static int[] lichrelNumbers =  {196, 295, 394, 493, 592, 689, 691, 788, 790, 879, 887, 978, 986};
    public static int sum(String[][] strArray) throws MyArrayDataException, MyArraySizeException {
        for (int i=0;i< strArray.length; i++){
            if (strArray.length != 4 || strArray[i].length != 4) throw new MyArraySizeException();
        }
        int sum = 0;
        for (int i = 0; i < strArray.length; i++) {
            for (int j = 0; j < strArray.length; j++) {

                try {
                    int temp = Integer.parseInt(strArray[i][j]);
                    sum += temp;
                } catch (NumberFormatException e) {
                    throw new MyArrayDataException(i, j);
                }

            }
        }
        for (int i = 0; i < strArray.length; i++) {
            for (int j = 0; j < strArray.length; j++) {
                try {
                    int temp = Integer.parseInt(strArray[i][j]);
                    for (int lichrelNumber : lichrelNumbers) {
                        if (lichrelNumber==temp)
                            throw new MyLichrelException(i, j);
                    }
                } catch (MyLichrelException e) {
                    e.printStackTrace();
                }

                try {
                    int temp = Integer.parseInt(strArray[i][j]);
                    if (Math.sqrt(temp) % 1 != 0 && Math.cbrt(temp) % 1 != 0)
                        throw new MyPowException(i, j);
                } catch (MyPowException e) {
                    e.printStackTrace();
                }

            }
        }
        return sum;
    }

    public static void main(String[] args) {
        String[][] matrix = {
                {"1", "226981", "3", "2"},
                {"314432", "160000", "512000", "223729"},
                {"125000", "729000", "681472", "970299"},
                {"804357", "196", "117649", "175616"}
        };

        try {
            System.out.println("Сумма всех элементов матрицы равна " + sum(matrix));
        } catch (MyArraySizeException | MyArrayDataException e) {
            e.printStackTrace();
        }
    }
}